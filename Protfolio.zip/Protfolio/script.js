// ============ Mobile nav ============
const toggleBtn = document.querySelector(".nav-toggle");
const nav = document.querySelector("[data-nav]");

toggleBtn?.addEventListener("click", () => {
  if (!nav) return;
  const open = nav.classList.toggle("open");
  toggleBtn.setAttribute("aria-expanded", open ? "true" : "false");
});

nav?.querySelectorAll("a").forEach(a => {
  a.addEventListener("click", () => {
    nav.classList.remove("open");
    toggleBtn?.setAttribute("aria-expanded", "false");
  });
});

// ============ Reveal on scroll ============
const revealEls = document.querySelectorAll(".reveal");
const io = new IntersectionObserver((entries) => {
  entries.forEach((e) => {
    if (e.isIntersecting) e.target.classList.add("in");
  });
}, { threshold: 0.12 });

revealEls.forEach(el => io.observe(el));

document.querySelector(".brand").addEventListener("click", (e) => {
  e.preventDefault();
  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });
});

// ===== Scroll Spy (stable) =====
const header = document.querySelector(".header");
const navLinks = document.querySelectorAll('.nav-links a[href^="#"]');

const sectionIds = [...navLinks]
  .map(a => a.getAttribute("href"))
  .filter(h => h && h.startsWith("#"))
  .map(h => h.slice(1));

const sections = sectionIds
  .map(id => document.getElementById(id))
  .filter(Boolean);

function clearActive() {
  navLinks.forEach(a => a.classList.remove("active"));
}

function setActive(id) {
  clearActive();
  const link = document.querySelector(`.nav-links a[href="#${id}"]`);
  if (link) link.classList.add("active");
}

function onScrollSpy() {
  const headerH = header ? header.offsetHeight : 0;
  const y = window.scrollY + headerH + 10;

  const home = document.getElementById("home");
  if (home) {
    const homeBottom = home.offsetTop + home.offsetHeight;
    if (y < homeBottom - 50) {
      clearActive();
      return;
    }
  }

  let currentId = null;
  for (const sec of sections) {
    if (y >= sec.offsetTop) currentId = sec.id;
  }

  if (currentId) setActive(currentId);
}

window.addEventListener("scroll", onScrollSpy, { passive: true });
window.addEventListener("load", onScrollSpy);
window.addEventListener("resize", onScrollSpy);

navLinks.forEach((a) => {
  a.addEventListener("click", () => {
    const id = a.getAttribute("href").replace("#", "");
    setActive(id);
  });
});


// ============ Counter animation ============
const counters = document.querySelectorAll("[data-counter]");
const counterIO = new IntersectionObserver((entries) => {
  entries.forEach((e) => {
    if (!e.isIntersecting) return;

    const el = e.target;
    const target = Number(el.getAttribute("data-counter")) || 0;
    const duration = 900;
    const start = performance.now();

    function tick(now) {
      const p = Math.min((now - start) / duration, 1);
      const val = Math.round(target * (0.2 + 0.8 * p));
      el.textContent = String(val);
      if (p < 1) requestAnimationFrame(tick);
      else el.textContent = String(target);
    }

    requestAnimationFrame(tick);
    counterIO.unobserve(el);
  });
}, { threshold: 0.6 });

counters.forEach(c => counterIO.observe(c));

// ============ Footer year ============
document.getElementById("year").textContent = new Date().getFullYear();

// ============ Blob follow (subtle) ============
const blobs = document.querySelectorAll(".blob");
let mx = 0, my = 0;
window.addEventListener("mousemove", (e) => {
  mx = (e.clientX / window.innerWidth - 0.5) * 20;
  my = (e.clientY / window.innerHeight - 0.5) * 20;
});
function animateBlobs(){
  blobs.forEach((b, i) => {
    const k = (i + 1) * 0.25;
    b.style.transform = `translate(${mx * k}px, ${my * k}px)`;
  });
  requestAnimationFrame(animateBlobs);
}
animateBlobs();

// ============ THEME TOGGLE (Dark/Light) ============
const themeBtn = document.getElementById("themeBtn");
const themeLabel = document.getElementById("themeLabel");
const root = document.documentElement;

function updateThemeUI(theme){
  if (!themeLabel || !themeBtn) return;

  const ico = themeBtn.querySelector(".theme-ico");

  if (theme === "light") {
    themeLabel.textContent = "Light";
    if (ico) ico.textContent = "☀";
    themeBtn.setAttribute("aria-label", "Switch to dark theme");
    themeBtn.title = "Switch to dark";
  } else {
    themeLabel.textContent = "Dark";
    if (ico) ico.textContent = "☾";
    themeBtn.setAttribute("aria-label", "Switch to light theme");
    themeBtn.title = "Switch to light";
  }
}

function applyTheme(theme){
  root.setAttribute("data-theme", theme);
  localStorage.setItem("theme", theme);
  updateThemeUI(theme);
}

(function initTheme(){
  const saved = localStorage.getItem("theme");
  if (saved === "light" || saved === "dark") {
    applyTheme(saved);
    return;
  }

  const prefersLight =
    window.matchMedia &&
    window.matchMedia("(prefers-color-scheme: light)").matches;

  applyTheme(prefersLight ? "light" : "dark");
})();

function rememberToggle(){
  const current = root.getAttribute("data-theme") || "dark";
  applyTheme(current === "dark" ? "light" : "dark");
}
themeBtn?.addEventListener("click", rememberToggle);

// ============ Safe HTML ============
function escapeHTML(str = "") {
  return str
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

// ============ PROJECTS (GitHub API) ============

// GitHub fail hole fallback e 4 project show
const FALLBACK_PROJECTS = [
  {
    name: "Fighter-Airplane-Shooting-OpenGL",
    description:
      "A C++ OpenGL (GLUT) based fighter airplane shooting game set in a war-torn city environment, featuring bullets, falling obstacles, sound effects, score & lives system, and smooth 60 FPS gameplay.",
    html_url: "https://github.com/DevVoyageR007/Fighter-Airplane-Shooting-OpenGL",
    homepage: "",
    updated_at: "2025-01-01T00:00:00Z"
  },
  {
    name: "SmartWaterPump",
    description:
      "SmartWaterPump is an IoT-based system that monitors tank water levels and controls the pump automatically. It turns the pump ON when water is low and OFF when full, preventing overflow and saving electricity. Simple, low-cost, and reliable, it's ideal for both home and industrial water management.",
    html_url: "https://github.com/DevVoyageR007/SmartWaterPump",
    homepage: "",
    updated_at: "2025-01-01T00:00:00Z"
  },

  {
    name: "QR Studio",
    description: "QR Studio is a modern, Django-based web application that allows users to create beautiful, customizable QR codes with real-time preview.Users can generate QR codes from URLs, phone numbers, or plain text and download them in multiple formats such as PNG, SVG, and PDF.",
    html_url: "https://github.com/DevVoyageR007/QR-Stdio",
    homepage: "",
    updated_at: "2025-01-01T00:00:00Z"
  },
  {
    name: "PixWasher",
    description: "Smart Background Removal Web Application. PixWasher is a modern, AI-powered web application that removes image backgrounds with a single click.Designed with a clean, interactive UI and a smooth step-by-step workflow, PixWasher delivers fast and high-quality cut-outs suitable for personal, academic, and professional use.",
    html_url: "https://github.com/DevVoyageR007/PixWasher-",
    homepage: "",
    updated_at: "2025-01-01T00:00:00Z"
  }
];

const GITHUB_USERNAME = "DevVoyageR007";
const PROJECT_LIMIT = 6;
const PROJECTS_CACHE_KEY = "cached_projects_v1";
const CACHE_TTL_MS = 1000 * 60 * 60 * 24; // 24 hours

function renderProjects(list, grid, note = "") {
  grid.innerHTML = `
    ${note ? `<p class="muted small">${escapeHTML(note)}</p>` : ""}
    ${list.map(repo => `
      <article class="card project reveal in">
        <div class="project-top">
          <span class="badge">GitHub</span>
          <span class="muted small">${repo.updated_at ? new Date(repo.updated_at).getFullYear() : new Date().getFullYear()}</span>
        </div>
        <h3 class="h3">${escapeHTML(repo.name)}</h3>
        <p class="muted">${escapeHTML(repo.description || "No description added yet.")}</p>
        <div class="project-actions">
          <a class="btn btn--sm" href="${repo.html_url}" target="_blank" rel="noopener noreferrer">Code</a>
          ${repo.homepage ? `<a class="btn btn--ghost btn--sm" href="${repo.homepage}" target="_blank" rel="noopener noreferrer">Live</a>` : ""}
        </div>
      </article>
    `).join("")}
  `;
}

function readProjectsCache() {
  try {
    const raw = localStorage.getItem(PROJECTS_CACHE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || !Array.isArray(parsed.items)) return null;
    return parsed; // { items: [], savedAt: number }
  } catch {
    return null;
  }
}

function writeProjectsCache(items) {
  try {
    localStorage.setItem(PROJECTS_CACHE_KEY, JSON.stringify({
      items,
      savedAt: Date.now()
    }));
  } catch {}
}

async function fetchGitHubProjects() {
  const url = `https://api.github.com/users/${GITHUB_USERNAME}/repos?sort=updated&per_page=100`;
  const res = await fetch(url, { cache: "no-store" });

  if (!res.ok) {
    // rate limit / forbidden etc.
    throw new Error(`GitHub API error: ${res.status}`);
  }

  const repos = await res.json();

  return repos
    .filter(r => !r.fork)
    .slice(0, PROJECT_LIMIT);
}

async function loadGitHubProjects() {
  const grid = document.getElementById("projectsGrid");
  if (!grid) return;

  const cached = readProjectsCache();
  if (cached?.items?.length) {
    const isStale = (Date.now() - cached.savedAt) > CACHE_TTL_MS;
    renderProjects(cached.items, grid, isStale ? "Updating projects..." : "");
  } else {
    grid.innerHTML = "<p class='muted'>Loading projects...</p>";
  }

  try {
    const fresh = await fetchGitHubProjects();
    writeProjectsCache(fresh);
    renderProjects(fresh, grid);
  } catch (err) {
    // ✅ GitHub fail -> cached না থাকলে fallback দেখাবে
    if (!cached?.items?.length) {
      renderProjects(FALLBACK_PROJECTS.slice(0, 4), grid);
    }
    console.warn("Projects load failed:", err);
  }
}

loadGitHubProjects();

document.querySelector(".to-top")?.addEventListener("click", (e) => {
  e.preventDefault();
  window.scrollTo({ top: 0, behavior: "smooth" });
});

// ============ CONTACT (Formspree) status ============
const contactForm = document.getElementById("contactForm");
const formStatus = document.getElementById("formStatus");

contactForm?.addEventListener("submit", async (e) => {
  const action = contactForm.getAttribute("action") || "";
  if (!action.includes("formspree.io")) return;

  e.preventDefault();
  if (formStatus) formStatus.textContent = "Sending...";

  try{
    const res = await fetch(action, {
      method: "POST",
      body: new FormData(contactForm),
      headers: { "Accept": "application/json" }
    });

    if (formStatus){
      if (res.ok){
        formStatus.textContent = "✅ Message sent successfully!";
        contactForm.reset();
      } else {
        formStatus.textContent = "❌ Something went wrong. Please try again.";
      }
    }
  }catch(err){
    if (formStatus) formStatus.textContent = "❌ Network error. Please try again.";
  }
});
